# Rubric Checklist (Marking Guide Mapping)

## Network Topologies Design & Simulation (70 marks assumed by brief; adapt to your sheet)
- **Topology Design Accuracy (15)**: Use provided configs & VLAN/IP tables precisely.
- **Device Configuration Notes (10)**: Comment each config block in `.cfg` files.
- **Successful Data Exchange Evidence (10)**: Include provided expected-result screenshots plus your own.
- **Hybrid Topology Creativity (10)**: Extended star core + two branches + server VLAN.
- **IP Addressing Plan (10)**: `docs/ip_tables.csv` complete for IPv4 & IPv6.
- **GitHub Documentation (10)**: README links, diagrams (`.mmd`), tables.
- **Video Demonstration Plan (5)**: See Part III script.

## Individual Network Feature Configuration (30 marks)
- **Central Router Default Routes (10)**: Part II configs present & working.
- **HTTP Server (10)**: DNS + HTTP reachable from VLAN10 & VLAN20.
- **Screenshots & Notes (10)**: Before/after tests + brief explanations.

